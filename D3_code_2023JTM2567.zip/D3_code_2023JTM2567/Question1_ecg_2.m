
ecg_2 = load('ecg_2.txt');  % Load ECG signals
fs = 360; % Hz    % Sampling rate

% Double median filtering

% Split the signal into segments
N=length(ecg_2);
sl = 10000; % Define the length of each segment
ts = ceil(N / sl); % Calculate the number of segments

% Initialize the filtered signal
xf = zeros(1, N);

% Processing each segments
for i = 1:ts
    start_idx = (i - 1) * sl + 1;
    end_idx = min(i * sl, N);
    segment = ecg_2(start_idx:end_idx);

    % First stage median filter
    xm1_segment = zeros(size(segment));   %Segment after median filtering
    ws_1 = fs/4;    %window size for first stage
    for n = 1:(fs/4)
        ws_1 = fs/4 + (fs/2 - fs/4) * (n-1) / (fs/4);
        if ws_1 < fs/4
            ws_1 = fs/4;
        end
        xm1_segment(n) = median(segment(1:min(n, length(segment))), 'all');  %median filtering on each segment
    end

    for n = (fs/4 + 1):(length(segment) - fs/4)
        xm1_segment(n) = median(segment((n-fs/4):(n+fs/4)), 'all'); %median filtering on segment
    end

    for n = (length(segment) - fs/4 + 1):length(segment)
        ws_1 = fs/2 - (fs/2 - fs/4) * (n - (length(segment) - fs/4)) / (fs/4);
        if ws_1 < fs/4
            ws_1 = fs/4;
        end
        xm1_segment(n) = median(segment(max(n-fs/2,1):end), 'all');    %median filtering on each segment
    end

    % Second stage median filter
    xm2_segment = zeros(size(segment));            %result of median filtering on each segment
    for n = 1:(fs/2)
        ws_2 = fs/2 + (fs - fs/2) * (n-1) / (fs/2);
        xm2_segment(n) = median(xm1_segment(1:min(n, length(segment))), 'all');
    end

    for n = (fs/2 + 1):(length(segment) - fs/2)
        xm2_segment(n) = median(xm1_segment((n-fs/2):(n+fs/2)), 'all');
    end

    for n = (length(segment) - fs/2 + 1):length(segment)
        ws_2 = fs - (fs - fs/2) * (n - (length(segment) - fs/2)) / (fs/2);
        xm2_segment(n) = median(xm1_segment(max(n-fs,1):end), 'all');
    end

    % Remove baseline drift for the current segment
    xf_segment = segment - xm2_segment;

    % Store the filtered segment in the final filtered signal
    xf(start_idx:end_idx) = xf_segment;         
end



% Enhance peaks by raising the absolute values of xf to the power of 6
xd = abs(xf).^6;

%Threshold to remove noise 

th_2 =mean(xd);
%th_2 =0.01*10^14;     %threshold below which all values become zero 
xd(xd < th_2) = 0;
disp(th_2);

% Finding the peaks
[pks,pks_ind] = findpeaks(xd);

%Calculation of RR interval

RR_ind = diff(pks_ind) ;    %Difference between consecutive indexes
RR_Interval= RR_ind*(1/fs) ;  %Finding the time at which these peak occurs in second

%Converting interval to Beap per minutes
BPM =zeros(length(RR_Interval),1);
i=1;
while(i<=length(BPM))
BPM(i)= (1/RR_Interval(i))*60;
i=i+1;
end

%set limit of BPM from 10 to 200  

for i = 1:length(BPM)
    if BPM(i) < 10 || BPM(i) > 200
        BPM(i) = 0;
    end
end

BPM_final = BPM(BPM> 0);   %BPM after thresholding

% Change in heart rate 
change = diff(BPM_final);

% Plot the ECG signal, first derivative, and second derivative with red color
figure;
subplot(3,1,1);
plot(ecg_2(1:3000), 'b');
xlabel('index');
ylabel('Amplitude');
title('ECG2 Signal');

subplot(3,1,2);
plot(xf(1:3000), 'b');
xlabel('index');
ylabel('amplitude');
title('two stage median filtering');

subplot(3,1,3);
plot(xd(1:3000), 'b');
xlabel('index');
ylabel('Sixth order power');
title('Sixth order power');



figure;
subplot(2,1,1)
plot(BPM_final,'g')
xlabel('Beat','FontSize',12.5);
ylabel('Heart Rate in BPM','FontSize',12.5); 
title('Heart Rate in Beat per minute - ecg2') ;
yline(mean(BPM_final),'r','LineWidth',1.5) ;

legend('Heart Rate','Mean Heart Rate')

subplot(2,1,2)
plot(change,'b')
xlabel('Beat','FontSize',12.5);
ylabel('Heart Rate Change (BPM)','FontSize',12.5); 
title('Change in Heart Rate Beat per minutes - ecg2') ;

hold on
yline(mean(change), 'LineWidth',1.5)


legend('Change in Heart Rate','Mean Change')

% Plot histogram
figure;
histogram(BPM_final, 'BinWidth', 4, 'FaceColor', 'g'); 
xlabel('Heart Rate (BPM)');
ylabel('Frequency');
title('Histogram of Heart Rate for ECG2');

% Plot change in histogram
figure;
histogram(change, 'BinWidth', 4, 'FaceColor', 'r');
xlabel('Change in Heart Rate (Beats per Minute)', 'FontSize', 12.5);
ylabel('Frequency', 'FontSize', 12.5);
title('Histogram for Heart Rate Change for ecg2');




%% Visual method

threshold = 1050;
ecg_2_updated = ecg_2;
ecg_2_updated(ecg_2 < threshold) = 0;

% Finding the peaks
[pks_vis,pks_ind_vis] = findpeaks(ecg_2_updated);

RR_ind_vis = diff(pks_ind_vis) ;    %Difference between consecutive indexes
RR_Interval_vis= RR_ind_vis*(1/fs) ;  %Finding the time at which these peak occurs in second

%Converting interval to Beap per minutes
BPM_vis =zeros(length(RR_Interval_vis),1);
i=1;
while(i<=length(BPM_vis))
BPM_vis(i)= (1/RR_Interval_vis(i))*60;
i=i+1;
end

%set limit of BPM from 10 to 200  

for i = 1:length(BPM_vis)
    if BPM_vis(i) < 10 || BPM_vis(i) > 200
        BPM_vis(i) = 0;
    end
end

BPM_vis_final = BPM_vis(BPM_vis> 0);   %BPM after thresholding


figure;
subplot(2,1,1);
plot(ecg_2(1:2000), 'm');
xlabel('index');
ylabel('ECG2');
title('ECG2');

subplot(2,1,2);
plot(ecg_2_updated(1:2000), 'm');
xlabel('index');
ylabel('ECG2_threshold');
title('ECG2 after threshold');

figure ;
plot(BPM_vis_final,'b*-')
hold on
plot(BPM_vis,'r*-')
hold off
xlabel('Beat Number','FontSize',12.5);
ylabel('Heat rate in Beats per Minute','FontSize',12.5); 
title('Hear Rate Detection using Visual Method - ecg2') ;
legend('Visual Method','median filter-power method')


%histogram comparison
figure;
hold on;
histogram(BPM_vis_final, 'FaceColor', 'b', 'EdgeColor', 'none', 'FaceAlpha', 0.7);
histogram(BPM_final, 'FaceColor', 'r', 'EdgeColor', 'none', 'FaceAlpha', 0.7);
hold off;
xlabel('Heart Rate (BPM)');
ylabel('Frequency');
title('Histogram of Heart Rate Comparison');
legend('Visual Method', 'median filter-power method');


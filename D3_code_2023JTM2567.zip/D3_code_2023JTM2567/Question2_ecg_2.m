ecg_2 = load('ecg_2.txt');  % Load ECG signals
fs = 360; % Hz    % Sampling rate

% Double median filtering

% Split the signal into segments
N=length(ecg_2);
sl = 10000; % Define the length of each segment
ts = ceil(N / sl); % Calculate the number of segments

% Initialize the filtered signal
xf = zeros(1, N);

% Processing each segments
for i = 1:ts
    start_idx = (i - 1) * sl + 1;
    end_idx = min(i * sl, N);
    segment = ecg_2(start_idx:end_idx);

    % First stage median filter
    xm1_segment = zeros(size(segment));   %Segment after median filtering
    ws_1 = fs/4;    %window size for first stage
    for n = 1:(fs/4)
        ws_1 = fs/4 + (fs/2 - fs/4) * (n-1) / (fs/4);
        if ws_1 < fs/4
            ws_1 = fs/4;
        end
        xm1_segment(n) = median(segment(1:min(n, length(segment))), 'all');  %median filtering on each segment
    end

    for n = (fs/4 + 1):(length(segment) - fs/4)
        xm1_segment(n) = median(segment((n-fs/4):(n+fs/4)), 'all'); %median filtering on segment
    end

    for n = (length(segment) - fs/4 + 1):length(segment)
        ws_1 = fs/2 - (fs/2 - fs/4) * (n - (length(segment) - fs/4)) / (fs/4);
        if ws_1 < fs/4
            ws_1 = fs/4;
        end
        xm1_segment(n) = median(segment(max(n-fs/2,1):end), 'all');    %median filtering on each segment
    end

    % Second stage median filter
    xm2_segment = zeros(size(segment));            %result of median filtering on each segment
    for n = 1:(fs/2)
        ws_2 = fs/2 + (fs - fs/2) * (n-1) / (fs/2);
        xm2_segment(n) = median(xm1_segment(1:min(n, length(segment))), 'all');
    end

    for n = (fs/2 + 1):(length(segment) - fs/2)
        xm2_segment(n) = median(xm1_segment((n-fs/2):(n+fs/2)), 'all');
    end

    for n = (length(segment) - fs/2 + 1):length(segment)
        ws_2 = fs - (fs - fs/2) * (n - (length(segment) - fs/2)) / (fs/2);
        xm2_segment(n) = median(xm1_segment(max(n-fs,1):end), 'all');
    end

    % Remove baseline drift for the current segment
    xf_segment = segment - xm2_segment;

    % Store the filtered segment in the final filtered signal
    xf(start_idx:end_idx) = xf_segment;         
end



% Enhance peaks by raising the absolute values of xf to the power of 6
xd = abs(xf).^6;

%Threshold to remove noise 

th_2 =mean(xd);
%th_2 =0.01*10^14;     %threshold below which all values become zero 
xd(xd < th_2) = 0;
disp(th_2);

% Finding the peaks
[pks,peak_indexes] = findpeaks(xd);

diff1_ecg_2 = diff(ecg_2);


%QRS detection

j = 1; % Initialize index variable
QRS_left = zeros(1, length(peak_indexes)); % Initialize array for left counters
QRS_right = zeros(1, length(peak_indexes)); % Initialize array for right counters

while j <= length(peak_indexes)
    location = peak_indexes(j);
    left_counter = 2;
    right_counter = 2;

    % Calculate left counter
    for i = 1:(location - 2)
        if diff1_ecg_2(location - 2 - i) <= 0
            break; % Exit the loop if the condition is not met
        end
        left_counter = left_counter + 1; % Count negative values of first difference before center
    end
    QRS_left(j) = left_counter;

    % Calculate right counter
    for k = 1:(length(diff1_ecg_2) - (location + 2))
        if diff1_ecg_2(location + 2 + k) >= 0
            break; % Exit the loop if the condition is not met
        end
        right_counter = right_counter + 1; % Count negative values of first difference after center
    end
    QRS_right(j) = right_counter;

    j = j + 1; % Increment outer loop index
end

QRS = QRS_left + QRS_right; % Calculate QRS values by adding corresponding elements

QRSinterval = QRS*(1/fs) ;

%Plotting Histograms


figure;
plot(ecg_2(1:800), 'r');
xlabel('Sample no.','FontSize',12.5);
ylabel('Amplitude','FontSize',12.5); 
title('ECG2');

figure;
plot(diff1_ecg_2(1:800), 'r');
xlabel('Sample no.','FontSize',12.5);
ylabel('Amplitude','FontSize',12.5); 
title('Difference of ECG2');




figure;
plot(QRSinterval, 'bo-', 'LineWidth', 1, 'MarkerSize', 1, 'MarkerEdgeColor', 'black', 'MarkerFaceColor', 'black');
xlabel('Beat No.','FontSize',12.5);
ylabel('QRS interval in seconds','FontSize',12.5); 
title('QRS Interval Estimation for ecg2');



figure;
histogram(QRSinterval, 50, 'FaceColor', 'blue');
xlabel('QRS Interval Bins (seconds)','FontSize',10);
ylabel('Frequency','FontSize',10); 
title('QRS Interval Estimation for ecg2');







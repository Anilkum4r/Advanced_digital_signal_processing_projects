load 'rf_data.mat';
rf_data;     
timestamp;    
z;


% SNR values to test
SNR_values = [5,10,15,30];

for SNR = SNR_values
    
    echo = rf_data(:, 1);
    
    % Add Gaussian noise
    noise_power = var(echo) / (10^(SNR/10));
    echo_n = echo + sqrt(noise_power) * randn(size(echo));

    % Apply filter
    filtered_echo = filter(Hd, echo_n);

    % Calculate FFT and frequency axis
    fft_echo_noisy = fft(echo_n);
    fft_filtered = fft(filtered_echo);
    fft_echo =fft(echo);

          N = length(rf_data);
   freq_axis = (-N/2:N/2-1)*(fs/N)/2;


 % Plot the spectrum of original and noisy echo signals
figure;
subplot(2,1,1);
plot(freq_axis/1e6, abs(fft_echo_noisy), 'LineWidth', 1);
xlabel('Time (s)');
ylabel('Amplitude');
title(['Noisy Echo (SNR = ' num2str(SNR) ' dB)']);

subplot(2,1,2);
plot(freq_axis/1e6, abs(fft_filtered));
xlabel('Time (s)');
ylabel('Amplitude');
title(['Filtered Echo (SNR = ' num2str(SNR) ' dB)']);

end
figure;
plot(freq_axis/1e6, abs(fft_echo), 'LineWidth', 1);
xlabel('Time (s)');
ylabel('Amplitude');
title('First echo');
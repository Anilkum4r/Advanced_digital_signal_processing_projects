%load data
load 'rf_data.mat';
rf_data;     
timestamp;    
z;

% Plot z
figure;
plot(z);
xlabel('Lag in terms of Samples');
ylabel('Axial distance in mm');
grid on;

%(code for chirsp pulse generation) 

fs = 20e6;                       % Sampling frequency
b = 10e-6;                        % duration of pulse
f1 = 1.5e6;         % Start freq
f2 = 4.5e6;          % End freq
t = 0:1/fs:b-1/fs;   %time vector
reference = sin(2*pi *(f1 + (f2 - f1)*t/b).*t);    %chirp pulse
ref = repmat(reference(:), 1,21);
current_length = size(ref, 1);
num_zeros = 500 - current_length;
ref_appended = [ref; zeros(num_zeros, size(ref, 2))]; %zeros appended to make it of size 500

d1 = zeros(21, 1);     %Distance by corrletaion processing method
d2 = zeros(21, 1);     %Distance by end point detection method

% 1 (a) correlation method
%---------------------------------------------------------------------------

%distance

for i = 1:21
   x=rf_data(:, i);
   y=ref(:, i);
    output = xcorr(x,y);
    [~, lag] = max(abs(output));
    lag1 = lag - 500;
    d1(i) = (((lag1 * 1500) / (fs*2)) + 0.150) * 1000;  %Distance calculation by lag
end
  d1_s = movmean(d1, 2);   %Smoothing by windowing 

%velocity calculation

  v1 = diff(d1_s) / (timestamp(2) - timestamp(1));

%abslute speed calculation
  
  s1= abs(v1);


% Plot for first echo
figure;
subplot(3, 1, 1);
plot(rf_data(:, 1));
xlabel('Samples');
ylabel('Magnitude');
title('First Echo');
grid on;

% Plot for chirp pulse
subplot(3, 1, 2);
plot(ref_appended);
xlabel('Samples');
ylabel('Amplitude');
title('Chirp Pulse');
grid on;

% Plot for correlation result
subplot(3, 1, 3);
plot(output);
xlabel('Samples in terms of lag (need to subtract 500 from it)');
ylabel('Correlation Amplitude');
title('Correlation Result of First Echo');
grid on;


  

% Plot for distance profile

figure;
subplot(2,1,1);
plot(timestamp, d1_s, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'black', 'Color', 'black');
xlabel('Time (s)');
ylabel('Distance of Target (mm)');
title('Range profile of Target by correlation processing with no noise');
grid on;

% Plot velocity profile
subplot(2,1,2);
plot(timestamp(1:end-1), v1, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'black', 'Color', 'black');
xlabel('Time (s)');
ylabel('Velocity (mm/sec)');
title('Velocity profile by correlation processing with no noise');
grid on;

% Plot for absolute speed profile
figure;
plot(timestamp(1:end-1), s1, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'black','Color', 'black');
xlabel('Time (s)');
ylabel('absolute speed (mm/s)');
title('absolute speed Profile of the Target by correlation processing');
grid on;



% 1(b) End point detection method
%---------------------------------------------------------------------------  

% energy calculation of first echo
e1 = abs(rf_data(:, 1)).^2;
e1_total = sum(e1);
e1_mean = e1_total / size(rf_data(:, 1), 1);  %mean energy of first echo
th = 1.1 * e1_mean;    %threshold value


for i = 1:21
    i1 = find(abs(rf_data(:, i)).^2 > th, 1);   %start index
    lag = i1;
    d2(i) = (((lag*1500) / (fs*2)) + 0.150) * 1000; %Distance calculation by lag 
end
  
   d2_s = movmean(d2, 2);  %smoothing by windowing

  %velocity calculation

  v2 = diff(d2_s) / (timestamp(2) - timestamp(1));

%abslute speed calculation
  
  s2= abs(v2);

% Plot for  first echo
figure;

subplot(2, 1, 1);
plot(rf_data(:, 1));
xlabel('Samples');
ylabel('Magnitude');
title('First Echo');
grid on;

% Plot energy of first echo
subplot(2, 1, 2);
plot(e1);
hold on;
plot([1, length(e1)], [th, th], 'r--', 'LineWidth', 1); % Plot threshold value
xlabel('Samples');
ylabel('Energy');
title('Energy of first echo');
legend('Energy', 'Threshold');
grid on;



% Plot for distance
figure;
subplot(2,1,1);
plot(timestamp, d2_s, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b', 'Color', 'b');
xlabel('Time (s)');
ylabel('Distance of Target (mm)');
title('Range profile of Target by end point detection method with no noise');
grid on;

% Plot for velocity
subplot(2,1,2);
plot(timestamp(1:end-1), v2, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b', 'Color', 'b');
xlabel('Time (s)');
ylabel('Velocity (mm/sec)');
title('Velocity profile by end point detection method with no noise');
grid on;

%plot for absolute speed
figure;
plot(timestamp(1:end-1), s2, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b' ,'Color', 'b');
xlabel('Time (s)');
ylabel('absolute speed (mm/s)');
title('absolute speed Profile of the Target by end point detection method');
grid on;



% Plot distances over time for both methods
figure;
plot(timestamp, d1_s, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b');
hold on;
plot(timestamp, d2_s, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'r');
hold off;
xlabel('Time (s)');
ylabel('Smoothed Distance (mm)');
title('Comparison of Distance Profiles');
legend('Correlation processing', 'End-point detection');
grid on;

% Plot velocity over time for both methods
figure;
plot(timestamp(1:end-1), v1, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b');
hold on;
plot(timestamp(1:end-1), v2, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'r');
hold off;
xlabel('Time (s)');
ylabel(' velocity (mm/sec)');
title('Comparison of velocity');
legend('Correlation processing', 'End-point detection');
grid on;


% Plot absolute speed over time for both methods
figure;
plot(timestamp(1:end-1), s1, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'b');
hold on;
plot(timestamp(1:end-1), s2, '-o', 'LineWidth', 1, 'MarkerSize', 3, 'MarkerFaceColor', 'r');
hold off;
xlabel('Time (s)');
ylabel('absolute speed (mm/sec)');
title('Comparison of absolute speed profile');
legend('Correlation processing', 'End-point detection');
grid on;



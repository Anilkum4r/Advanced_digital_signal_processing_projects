%load data
load 'rf_data.mat';
rf_data;     
timestamp;    
z;

%(code for chirsp pulse generation) 

fs = 20e6;                       % Sampling frequency
b = 10e-6;                        % duration of pulse
f1 = 1.5e6;         % Start freq
f2 = 4.5e6;          % End freq
t = 0:1/fs:b-1/fs;   %time vector

reference = sin(2*pi *(f1 + (f2 - f1)*t/b).*t);
ref = repmat(reference(:), 1, 21); 

SNR_values = [5,10,15,30];    % SNR values 

% Preallocate arrays to store results
d1_f = zeros(21, numel(SNR_values));   %final distance with noise 
v1_f = zeros(20, numel(SNR_values));   %final velocity with noise 
s1_f = zeros(20, numel(SNR_values));   %final absolute speed with noise 

for k = 1:4
    SNR = SNR_values(k);

    % Add noise 
    for i = 1:21
        echo = rf_data(:, i);   
        n = var(echo) / (10^(SNR/10));     % Calculate noise power
        echo_n = echo + sqrt(n) * randn(size(echo));      % Add Gaussian noise

        echo_filtered = filter(Hd, echo_n);          % Apply filter, here Hd is filter object

        % Cross-correlation method
        output = xcorr(echo_filtered, ref(:, i));
        [~, lag] = max(abs(output));
        lag1 = lag - 500;
        d1 = (((lag1 * 1500) / (fs*2)) + 0.150) * 1000;  
        d1_f(i, k) = d1; 
    end

    
    v1_f(:, k) = diff(d1_f(:, k)) / (timestamp(2) - timestamp(1)); % Calculate velocity

   
    s1_f(:, k) = abs(v1_f(:, k));    % Calculate absolute speed
end


% Plot distance and velocity for different SNRs

figure;
subplot(2,1,1);
plot(timestamp, d1_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Distance of Target (mm)');
title('Filtered Range Profile of Target by Correlation Method');
legendCell = cellstr(num2str(SNR_values', 'SNR = %-d dB'));
legend(legendCell);
grid on;

subplot(2,1,2);
plot(timestamp(1:end-1), v1_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Velocity (mm/sec)');
title('Filtered Velocity Profile by Correlation Method');
legend(legendCell);
grid on;


% Plot of filterd and actual echo

figure;
subplot(2,1,1);
plot(echo(:,1));
xlabel('Sample Index');
ylabel('Amplitude');
title('First Echo Signal');
grid on;

subplot(2,1,2);
plot(echo_filtered(:,1));
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered First Echo Signal');
grid on;




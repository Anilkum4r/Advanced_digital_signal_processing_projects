%load data
load 'rf_data.mat';
rf_data;     
timestamp;    
z;

SNR_values = [5,10,15,30];    % SNR values 


d2_f = zeros(21, numel(SNR_values));   %final distance with noise for endpoint detection
v2_f = zeros(20, numel(SNR_values));   %final velocity with noise for endpoint detection
s2_f = zeros(20, numel(SNR_values));   %final absolute speed with noise for endpoint detection


for k = 1:4
    SNR = SNR_values(k);

    % Add noise 
    for i = 1:21

        n = var(echo) / (10^(SNR/10));    % Calculate noise power   

        echo = rf_data(:, i);     %actual echo
       
        echo_n = echo + sqrt(n) * randn(size(echo));   % Add Gaussian noise
        echo_filtered = filter(Hd, echo_n);          % Filter applied

        % Threshold calculation
        e1 = abs(echo_filtered(:, 1)).^2;   %enersy of 1st echo
        e1_total = sum(e1);          
        e1_mean = e1_total/500;  % Mean energy of first echo
        th = 1.1 * e1_mean;    % Threshold value
        

        % Detection
        i1 = find(abs(echo_filtered).^2 > th, 1);   % Start index
        lag = i1;
        d2 = (((lag*1500) / (fs*2)) + 0.150) * 1000;  %distance calculation 
        d2_f(i, k) = d2;   %assign to distance vector
    end

    % Calculate velocity
    v2_f(:, k) = diff(d2_f(:, k)) / (timestamp(2) - timestamp(1));

    % Calculate absolute speed
    s2_f(:, k) = abs(v2_f(:, k));
end



% Plot distance for different SNRs
figure;
subplot(2,1,1);
plot(timestamp, d2_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Distance of Target (mm)');
title('Range Profile of Target by Endpoint Detection Method after filtering');
legendCell = cellstr(num2str(SNR_values', 'SNR = %-d dB'));
legend(legendCell);
grid on;

% Plot velocity for different SNRs
subplot(2,1,2);
plot(timestamp(1:end-1), v2_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Velocity (mm/sec)');
title('Velocity Profile by Endpoint Detection Method after filtering');
legend(legendCell);
grid on;


% Plot of filterd and actual echo

figure;
subplot(2,1,1);
plot(echo(:,1));
xlabel('Sample Index');
ylabel('Amplitude');
title('First Echo Signal');
grid on;

subplot(2,1,2);
plot(echo_filtered(:,1));
xlabel('Sample Index');
ylabel('Amplitude');
title('Filtered First Echo Signal');
grid on;

%load data
load 'rf_data.mat';
rf_data;     
timestamp;    
z;

SNR_values = [5,10,15,30];    % SNR values 

d2_f = zeros(21, numel(SNR_values));   %final distance with noise for endpoint detection
v2_f = zeros(20, numel(SNR_values));   %final velocity with noise for endpoint detection
s2_f = zeros(20, numel(SNR_values));   %final absolute speed with noise for endpoint detection

% Threshold calculation
 e1 = abs(rf_data(:, 1)).^2;   %enersy of 1st echo
 e1_total = sum(e1);          
 e1_mean = e1_total /500;  % Mean energy of first echo
 th = 1.1 * e1_mean;    % Threshold value

for k = 1:4
    SNR = SNR_values(k);

    % Add noise 
    for i = 1:21
        echo = rf_data(:, i);      %actual echo
        n = var(echo) / (10^(SNR/10));    % Calculate noise power   
        echo_n = echo + sqrt(n) * randn(size(echo));   % Add Gaussian noise   

        % Detection
        i1 = find(abs(echo_n).^2 > th, 1);   % Start index
        lag = i1;
        d2 = (((lag*1500) / (fs*2)) + 0.150) * 1000;
        d2_f(i, k) = d2;
    end

    % Calculate velocity
    v2_f(:, k) = diff(d2_f(:, k)) / (timestamp(2) - timestamp(1));

    % Calculate absolute speed
    s2_f(:, k) = abs(v2_f(:, k));
end


% Plot distance for different SNRs

figure;
subplot(2,1,1);
plot(timestamp, d2_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Distance of Target (mm)');
title('Range Profile of Target by Endpoint Detection Method with noise');
legendCell = cellstr(num2str(SNR_values', 'SNR = %-d dB'));
legend(legendCell);
grid on;

% Plot velocity for different SNRs
subplot(2,1,2);
plot(timestamp(1:end-1), v2_f, '-o', 'LineWidth', 1, 'MarkerSize', 1);
xlabel('Time (s)');
ylabel('Velocity (mm/sec)');
title('Velocity Profile by Endpoint Detection Method with noise');
legend(legendCell);
grid on;

load('p2.mat'); % Contains pitch vector for s1.wav
[ip, fs] = audioread('s2.wav');


energy = sum(ip.^2); % Calculate energy of the signal


mean_energy = energy / length(ip); % Calculate mean energy


threshold = 0.09 * mean_energy; % Set threshold

% Remove parts below the threshold
y_cleaned = ip;
y_cleaned(abs(ip) < sqrt(threshold)) = 0;

frame_len = 80;

pitch = zeros(1, 300); %Initialization of pitch vector

for k = 1 : length(y_cleaned)/frame_len - 1
    range = (k-1)*frame_len + 1:k*frame_len;
    Selected_frame = y_cleaned(range);

    % Calculate autocorrelation
    [corr, lag] = xcorr(Selected_frame, Selected_frame);
    corr(find(corr < 0)) = 0;  % Set negative correlations to zero

    % Find peak and estimate period
    center_peak_width = find(corr(frame_len:end) == 0, 1);
     if ~isempty(center_peak_width)
        mask_width = min(center_peak_width, length(corr) - frame_len - center_peak_width);
        corr(frame_len - mask_width:frame_len + mask_width + 1) = min(corr);
    else
        % Handle where no zero peak is found 
        center_peak_width = 0;
        mask_width = 0;  % Or another appropriate value for short frames
        corr(frame_len - mask_width:frame_len + mask_width + 1) = min(corr);
    end
    [peak, loc] = max(corr);
    period = abs(loc - length(Selected_frame)+1);

   % pitch calculation
    pitch(k) = fs / period;
end


% set the range of desired pitch for female it is from 50Hz to 350Hz
for i = 2:length(pitch)
    if pitch(i) > 220
        pitch(i) = pitch(i-1);
    end
end

%For zero signal we are getting some default value of 102.564 make it zero.
for i = 2:length(pitch)
    if pitch(i) <102.565
        pitch(i) = 0;
    end
end

%Comparison of Actual pitch with calculated pitch
subplot(2, 1, 2);
plot(p2, 'b', 'LineWidth', 1.5);
hold on;
plot(pitch, 'g', 'LineWidth', 1.5);
xlabel('Time (10 ms frames)');
ylabel('Pitch (Hz)');
title('Comparison of Detected pitch with actual pitch');
legend('Actual Pitch', 'Detected pitch');

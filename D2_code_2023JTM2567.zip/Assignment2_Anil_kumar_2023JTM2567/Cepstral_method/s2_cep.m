%%cepstral method is not giving accurate results for low pitch voice samples

load('p2.mat');

% Read the speech signal file in y
[y,fs]=audioread('s2.wav');

%Threshold to remove noise
energy = sum(y.^2); % Calculate energy of the signal
mean_energy = energy / length(y); % Calculate mean energy
threshold = 0.09 * mean_energy; % Set threshold
y_cleaned = y;
y_cleaned(abs(y) < sqrt(threshold)) = 0;

max_pitch_freq = fs / 2; % Maximum possible pitch frequency
Frame_size = 80;     % Each frame of 80 samples
pitch = zeros(1,300);    %Initialize pitch vector


for i=1:300
    frame = y_cleaned(1+(i-1)*80:i*80);  % choose each frame to process

    % Calculation of cepstrum
    fft_frame = fft(frame);          
    mag_of_spectrum_square = (abs(fft_frame)).^2;   
    cepstrum = ifft(log(mag_of_spectrum_square));    

 
    half_cepstrum = cepstrum(1:length(cepstrum)/2);    % Because of symmetricity half of the coefficients used


    % Apply  Liftering
    Lift_window = zeros(1, length(half_cepstrum)); % liftering window
    Lift_cutoff = 10; % liftering cut off length, usually 15 or 20
    Lift_window(Lift_cutoff:length(Lift_window)) = 1; %Rectangle window
    high_time_cepstrum = real(half_cepstrum .* Lift_window'); % transpose of the liftering window
     
    %Pitch calculation 
    [max_value, lag] = max(real(high_time_cepstrum)); % lag is corrosponds to index of maximum value of high time cepstrum
    pitch_frequency = fs/lag;

    % Check if pitch frequency is too high (likely indicating silence)
    if pitch_frequency > max_pitch_freq
        pitch_frequency = 0; 
    end
    
    % Assign to array of pitch frequencies
    pitch(i) = pitch_frequency;

end

%Ajust frequencies according to range of male frequencies 50hz to 350Hz 
for i = 2:length(pitch)
    if pitch(i) > 400
        pitch(i) = pitch(i-1);
    end
end
for i = 2:length(pitch)
    if pitch(i) < 0
        pitch(i) = 0;
    end
end

subplot(2, 1, 1);
plot(y, 'b', 'LineWidth', 0.5);
hold on;

% Plot the filtered pitch contour
subplot(2, 1, 2);
plot(p2, 'r', 'LineWidth', 1.5);
hold on;
plot(pitch(2:300), 'g', 'LineWidth', 1.5);
xlabel('Time (10 ms frames)');
ylabel('Pitch (Hz)');
title('Pitch estimation of s1.wave');
legend('Actual Pitch', 'Estimated pitch');



